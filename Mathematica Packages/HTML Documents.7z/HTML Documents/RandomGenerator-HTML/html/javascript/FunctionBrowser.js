FunctionBrowserData = {
0:{"children":[1,957,1301,2740,3338,4055,5463,6593,7723]},
1:{"type":"node","href":"guide/CoreLanguageOverview","title":"Core Language","children":[2,134,262,327,409,435,567,662,786,908],"parent":0},
957:{"type":"node","href":"guide/DynamicInteractivityOverview","title":"Dynamic Interactivity","children":[958,1013,1037,1107,1121,1135],"parent":0},
1301:{"type":"node","href":"guide/MathematicsAndAlgorithmsOverview","title":"Mathematics and Algorithms","children":[1302,1866,1967,2100,2114,2265,2277,2312,2474,2553,2617,2689,2715,2728],"parent":0},
2740:{"type":"node","href":"guide/VisualizationAndGraphicsOverview","title":"Visualization and Graphics","children":[2741,2793,2841,2864,3069,3097,3271,3315,3322],"parent":0},
3338:{"type":"node","href":"guide/DataHandlingAndDataSourcesOverview","title":"Data Handling & Data Sources","children":[3339,3578,3710,3792,3819,3843,3861,3888,3910,3987,4028],"parent":0},
4055:{"type":"node","href":"guide/NotebooksAndDocumentsOverview","title":"Notebooks and Documents","children":[4056,4110,4305,5193,5225,5281,5334,5341,5350,5378],"parent":0},
5463:{"type":"node","href":"guide/SystemsInterfacesAndDeploymentOverview","title":"Systems Interfaces & Deployment","children":[5464,5595,5744,5813,5840,6045,6201,6336,6447,6526,6538,6556],"parent":0},
6593:{"type":"node","href":"guide/SystemsInterfacesAndDeploymentOverview","title":"Application Areas","children":[6594,6725,6874,6943,6970,7175,7331,7466,7577,7656,7668,7686],"parent":0},
7723:{"type":"node","href":"guide/NewIn60AlphabeticalListing","title":"New In 6.0","children":[7724,7786,7821,8128,8281,8445,8515,8540],"parent":0}}