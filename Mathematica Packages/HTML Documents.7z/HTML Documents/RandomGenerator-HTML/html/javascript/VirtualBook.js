VirtualBookData = {
0:{"children":[1,27,253,1050,1130,1240,1247,1267]},
1:{"type":"node","href":undefined,"title":"Introduction","children":[2,6,14,19,23],"parent":0},
27:{"type":"node","href":undefined,"title":"Core Language","children":[28,34,49,55,63,79,93,99,111,127,170,187],"parent":0},
253:{"type":"node","href":undefined,"title":"Mathematics and Algorithms","children":[254,267,277,290,307,321,335,353,369,382,411],"parent":0},
1050:{"type":"node","href":undefined,"title":"Visualization and Graphics","children":[1051,1061,1080],"parent":0},
1130:{"type":"node","href":undefined,"title":"Notebooks and Documents","children":[1131,1138,1154,1204,1218],"parent":0},
1240:{"type":"node","href":undefined,"title":"Dynamic Interactivity","children":[1241,1242,1243,1244,1245,1246],"parent":0},
1247:{"type":"node","href":undefined,"title":"Data Handling and Data Sources","children":[1248,1261],"parent":0},
1267:{"type":"node","href":undefined,"title":"Systems Interfaces and Deployment","children":[1268,1275,1281,1284,1371,1549,1660,1750,1789,1860],"parent":0}}